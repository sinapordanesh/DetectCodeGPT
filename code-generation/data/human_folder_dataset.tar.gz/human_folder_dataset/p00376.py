def main():
     x = list(map(int,input().split()))
     print(abs(x[0]-x[1]))

if __name__ == '__main__':
    main()
