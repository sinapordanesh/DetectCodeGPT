# -*- coding:utf-8 -*-

def main():
    IN=input()
    IN.upper()

    print(IN.upper())
        
if __name__ == '__main__':
    main()